# Zindigon — 2026 rebrand

Drop-in site files for `zindigon.github.io`. Replaces every page **except** the playable game folders, which stay untouched.

## What's in here

```
site/
├── index.html                 ← Home (live leaderboard + featured + projects)
├── projects.html              ← Games + Bloodline Zero unified
├── work.html                  ← Services + Partners merged
├── contact.html
├── ai-chat.html               ← Refreshed Realm Assistant demo
├── reset-password.html
├── 404.html
├── assets/
│   ├── site.css               ← Single design system
│   └── site.js                ← Nav, clock, leaderboard, versions, parallax
└── _partials/
    └── header.html            ← Reference for shared header/nav
```

## What was preserved (do not touch)

- `/Games/AetherFall/` (incl. leaderboards, privacy)
- `/Anime/BloodlineZero/`
- `/elementalrift/` and version history
- `/hypercell/`, `/nexusdefense/`, `/tornix/`
- `assets/leaderboards.js` (still used by AetherFall)
- `ads.txt`, `CNAME`

## Drop-in instructions

1. Copy everything in `site/` to your repo root.
2. **Delete** the old `services.html`, `partners.html`, `Partners.html`, `Contact.html` — the new `work.html` and `contact.html` replace them.
3. Existing internal links from inside the playable game folders that point to `/services.html` or `/partners.html` will 404; either leave them or do a one-time find/replace to `/work.html`.

## Design system

- **Background:** `#0A0A0C` near-black with a single mint accent — `oklch(0.85 0.15 165)`.
- **Type:** Instrument Serif (display) · Inter Tight (UI) · JetBrains Mono (metadata).
- **Logo:** SVG `Z` monogram in a small bordered square. Defined inline in every page (no asset to load).
- **FX:** Quiet animated dot grid with scroll parallax + a single faint accent glow at the top + 3.5% film grain. No starfield, no aurora, no scanlines.
- **One accent rule:** mint is used as ink (links, dots, CTAs). It never glows.

## Real-time hooks

- **Leaderboard** (`/index.html`) — pulls from your existing JSONBin (`#69fb6fae6373f77b4253ba55`). Auto-refresh button included. Falls back to `localStorage` if offline.
- **Live clock** in the nav bar updates every 30s.
- **Patch notes** are surfaced on home + projects from `window.ZIN_VERSIONS` in `site.js` — edit that array to push updates. The home hero "Status" line auto-reads the latest entry.

## Tagline

> Independent studio. Games, worlds, and the web.

## Email used throughout

`banderson@zindigon.com` (matches what was already on the site)
